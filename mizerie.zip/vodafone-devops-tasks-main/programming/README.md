# Programming

## Notes
```
  We provide 3 different variants of the same program (Python, Bash and Javascript).
  Choose the language that you prefer and feel more comfortable with, all of them have the same scope.
```

&nbsp;
## Task
---
Answer the following questions:

- Which language(s) did you choose?
- What's the purpose of `method1`?
- What's the purpose of `method2`?
- What's the purpose of `method3`?
