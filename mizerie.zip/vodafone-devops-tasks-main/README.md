# Vodafone - Tasks of a DevOps Engineer

The tasks described herein try to cover different experience levels in 6 different areas and simulates the daily activies of a DevOps Engineer at Vodafone.
The aim is to give you an idea about what we do and to showcase some challenges that you may face.

## Knowledge Coverage
- Docker
- Kubernetes
- Terraform
- Monitoring
- Troubleshooting
- Programming

## Your Environment Requirements
- Docker

```
You must have Docker installed on your laptop. It is the only requirement we ask, because all tools will be wrapped inside containers.
This is how we will review your solution.
```

## How to Start
We have split the tasks into 3 big sections `kubernetes`, `programming` and `terraform`
All of them have their own README&#46;md to guide you. There are no dependencies between each section, so it is up to you where to start.

## Notes
After receiving the tasks we ask you to send back a first version of your solutions within `1 hour`. If you need, or want to spend more time on the tasks, just tell us that you intend to send an updated version later.

The tasks are a little broad and we don't expect you to fully complete them. So please add as many comments as you want to explain what would you do to solve the missing parts.

In case the tasks descriptions are not clear or if you are stuck somewhere, please contact us at any time! We value collaboration and asking questions.

Doing the sections listed in `Knowledge Coverage` partially is much better than doing 100% of a single section.
Remember, the goal is for you to show us your experience and problem solving skills!

See you in the next phase!